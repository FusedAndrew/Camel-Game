import random
#This is the introduction to the game.
print("Welcome to 'Camel' created by Andrew Madera!")
print("You have stolen a camel to make your way across the great Mobi desert.")
print("The natives want their camel back and are chasing you down!")
print("Survive your desert trek and out run the natives.")
print(
    "Instructions: You have to trek across 200 miles and not get caught by the natives chasing you."
)
print(
    "Although be mindful of your Camel's tiredness, your thirst, the amount of Canteens you have, and how close the natives are to you!"
)
print("Also, ALL answers are case-sensitive e.g Q=Q A=A etc.")
print("Good luck and have fun!")
#Variables.
done = False
Miles_Traveled = 0
Thirst = 0
Camel_Tiredness = 0
Natives_Traveled = -20
Canteens_Owned = 3
At_Oasis = False
Oasis_Chance = 0
Gotten_Oasis = False
#Coding starts.
while done == False:
    print("A. Drink from your canteen.")
    print("B. Go ahead moderate speed.")
    print("C. Go ahead full speed.")
    print("D. Stop for the night.")
    print("E. Status check.")
    print("Q. Quit.")
    Answer = input("What do you choose?")
    if Answer == ("Q"):
        End = input("Are you sure? 'Yes' or 'No'")
        if End == ("Yes"):
            print("Game Over!")
            done = True
    elif Answer == ("E"):
        print("Miles Traveled:", Miles_Traveled)
        print("Drinks in Canteens:", Canteens_Owned)
        print("The Natives are", Miles_Traveled - Natives_Traveled,
              "miles behind you!")
    elif Answer == ("D"):
        print("Your Camel is happy and no longer tired!")
        Camel_Tiredness = 0
        Natives_Traveled = Natives_Traveled + random.randrange(7, 15)
    elif Answer == ("C"):
        Miles_Traveled = Miles_Traveled + random.randrange(10, 21)
        print("You have treked")
        print(Miles_Traveled)
        print("miles!")
        Thirst = Thirst + 1
        Camel_Tiredness = Camel_Tiredness + random.randrange(1, 3)
        Natives_Traveled = Natives_Traveled + random.randrange(7, 15)
        if Gotten_Oasis == False:
            Oasis_Chance = random.randrange(1, 51)
    elif Answer == ("B"):
        Miles_Traveled = Miles_Traveled + random.randrange(5, 13)
        print("You have treked")
        print(Miles_Traveled)
        print("miles!")
        Camel_Tiredness = Camel_Tiredness + 1
        Thirst = Thirst + 0.5
        Natives_Traveled = Natives_Traveled + random.randrange(7, 15)
        if Gotten_Oasis == False:
            Oasis_Chance = random.randrange(1, 51)
    elif Answer == ("A"):
        if Canteens_Owned > 0:
            Canteens_Owned = Canteens_Owned - 1
            Thirst = 0
            print("You are no longer thirtsy!")
        if Canteens_Owned == 0:
            print("You don't have anymore canteens.")
    if 15 >= Miles_Traveled - Natives_Traveled:
        print("The natives are close behind you!")
    if Natives_Traveled >= Miles_Traveled:
        print("The natives have caught you!")
        print("Game Over!")
        done = True
    if Camel_Tiredness >= 7:
        print("Your Camel has died of exhaustion!")
        print("Game Over!")
        done = True
    if Camel_Tiredness >= 3:
        print("Your Camel is getting tired!")
    if Miles_Traveled >= 200:
        print("Congratulations!")
        print("You have gotten away from the natives!")
        print("Game Over!")
        done = True
    if Thirst == 5:
        print("You have died of thirst!")
        print("Game Over!")
        done = True
    if Thirst >= 3:
        print("You are getting thirsty!")
    if Oasis_Chance == 50:
        At_Oasis = True
        Gotten_Oasis = True
        Oasis_Chance = 0
    if At_Oasis == True:
        Canteens_Owned = 3
        Thirst = 0
        print("You have found an Oasis!")
        print("You canteens have been filled and you are no longer thirsty!")
        At_Oasis = False